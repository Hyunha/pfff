package com.android.location.provider;
class LocationProvider {
  int mProvider;
  int mLocationManager;
  int TAG;
}
class GeocodeProvider {
  int mProvider;
}
