package com.android.vcard.exception;
class VCardVersionException {
}
class VCardNotSupportedException {
}
class VCardNestedException {
}
class VCardInvalidLineException {
}
class VCardInvalidCommentLineException {
}
class VCardException {
}
class VCardAgentNotSupportedException {
}
