package android.test.suitebuilder.examples.instrumentation;
class InstrumentationTest {
}
