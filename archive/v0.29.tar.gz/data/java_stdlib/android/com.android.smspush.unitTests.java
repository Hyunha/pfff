package com.android.smspush.unitTests;
class WapPushTest {
  int mWapPush;
  int mConn;
  int mIVerify;
  int OMA_CONTENT_TYPE_NAMES;
  int OMA_CONTENT_TYPE_VALUES;
  int OMA_APPLICATION_ID_NAMES;
  int OMA_APPLICATION_ID_VALUES;
  int mWspContentTypeStart;
  int mWspHeaderLen;
  int mWspHeaderStart;
  int mMessageBody;
  int mWspHeader;
  int mUserDataHeader;
  int mGsmHeader;
  int mClassName;
  int mPackageName;
  int mContentTypeName;
  int mContentTypeValue;
  int mAppIdName;
  int mAppIdValue;
  int TIME_WAIT;
  int LOCAL_LOGV;
  int LOG_TAG;
}
class ReceiverService {
  int LOG_TAG;
}
class ReceiverActivity {
  int LOG_TAG;
}
class DrmReceiver {
  int LOG_TAG;
}
class DataVerify {
  int binder;
  class IDataVerifyStub {
    int mContext;
  }
  int sDataSet;
  int mLastReceivedPdu;
  int WAIT_COUNT;
  int TIME_WAIT;
  int LOG_TAG;
}
class ClientTest {
  int conn;
  int mWapPushMan;
  int LOG_TAG;
}
