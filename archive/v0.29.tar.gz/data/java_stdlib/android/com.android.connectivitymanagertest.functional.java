package com.android.connectivitymanagertest.functional;
class WifiConnectionTest {
  class WifiServiceHandler {
  }
  int enabledNetworks;
  int mChannel;
  int mWifiManager;
  int mRunner;
  int mAct;
  int networks;
  int DEBUG;
  int TAG;
}
class ConnectivityManagerMobileTest {
  int mWifiOnlyFlag;
  int wl;
  int cmActivity;
  int mTestAccessPoint;
  int LOG_TAG;
}
