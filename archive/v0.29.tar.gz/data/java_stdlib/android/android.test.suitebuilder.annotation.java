package android.test.suitebuilder.annotation;
class HasMethodAnnotationTest {
  class AnnotatedMethodExample {
  }
}
class HasMethodAnnotation {
  int annotationClass;
}
class HasClassAnnotationTest {
  class NonSmokeTestExample {
  }
  class SmokeTestExample {
  }
}
class HasClassAnnotation {
  int annotationClass;
}
class HasAnnotationTest {
  class ClassWithoutAnnotation {
  }
  class ClassWithAnnotation {
  }
}
class HasAnnotation {
  int hasMethodOrClassAnnotation;
}
