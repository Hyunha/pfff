package com.android.commands.ime;
class Ime {
  int IMM_NOT_RUNNING_ERR;
  int mCurArgData;
  int mNextArg;
  int mArgs;
  int mImm;
}
