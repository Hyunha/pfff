package com.android.internal.preference;
class YesNoPreference {
  class SavedState {
    int CREATOR;
    int wasPositiveResult;
  }
  int mWasPositiveResult;
}
