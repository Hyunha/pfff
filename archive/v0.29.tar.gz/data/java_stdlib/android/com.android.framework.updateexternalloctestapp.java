package com.android.framework.updateexternalloctestapp;
class UpdateExternalLocTestAppActivity {
}
