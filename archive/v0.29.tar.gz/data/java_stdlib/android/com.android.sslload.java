package com.android.sslload;
class SslLoad {
  int running;
  int button;
  int TAG;
}
