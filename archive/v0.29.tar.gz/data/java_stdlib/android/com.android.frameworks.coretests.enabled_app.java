package com.android.frameworks.coretests.enabled_app;
class EnabledService {
}
class EnabledReceiver {
}
class EnabledProvider {
}
class EnabledActivity {
}
class DisabledService {
}
class DisabledReceiver {
}
class DisabledProvider {
}
class DisabledActivity {
}
