package android.filterfw.geometry;
class Rectangle {
}
class Quad {
  int p3;
  int p2;
  int p1;
  int p0;
}
class Point {
  int y;
  int x;
}
