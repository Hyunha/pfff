package com.android.inputmethodcommon;
class InputMethodSettingsInterface {
}
class InputMethodSettingsImpl {
  int mContext;
  int mImi;
  int mImm;
  int mSubtypeEnablerIcon;
  int mSubtypeEnablerIconRes;
  int mSubtypeEnablerTitle;
  int mSubtypeEnablerTitleRes;
  int mInputMethodSettingsCategoryTitle;
  int mInputMethodSettingsCategoryTitleRes;
  int mSubtypeEnablerPreference;
}
class InputMethodSettingsFragment {
  int mSettings;
}
class InputMethodSettingsActivity {
  int mSettings;
}
