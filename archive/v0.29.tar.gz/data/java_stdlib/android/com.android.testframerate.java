package com.android.testframerate;
class TestFramerateView {
  class Renderer {
  }
  int mNumShortFramesElapsed;
  int mLastTime_us;
  int TAG;
}
class TestFramerateActivity {
  int mView;
}
