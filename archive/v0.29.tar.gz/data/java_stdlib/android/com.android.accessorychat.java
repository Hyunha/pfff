package com.android.accessorychat;
class AccessoryChat {
  int mHandler;
  int mUsbReceiver;
  int MESSAGE_LOG;
  int mPermissionRequestPending;
  int mPermissionIntent;
  int mUsbManager;
  int mOutputStream;
  int mInputStream;
  int mFileDescriptor;
  int mEditText;
  int mLog;
  int ACTION_USB_PERMISSION;
  int TAG;
}
