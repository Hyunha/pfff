package com.android.framework.externalsharedpermstestapp;
class ExternalSharedPermsTest {
  int REQUEST_ENABLE_BT;
}
