package com.example.android.rs.fountainfbo;
class FountainFboView {
  int mRender;
  int mRS;
}
class FountainFboRS {
  int holdingColor;
  int mTextureProgramFragment;
  int mProgramFragment;
  int mColorBuffer;
  int mScript;
  int mRS;
  int mRes;
  int PART_COUNT;
}
class FountainFbo {
  int mView;
  int LOG_ENABLED;
  int DEBUG;
  int LOG_TAG;
}
