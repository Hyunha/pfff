package com.android.mediaframeworktest.functional.videoeditor;
class VideoEditorPreviewTest {
  int minWaitingTime;
  int previewError;
  int previewStop;
  int previewStart;
  int mEventHandler;
  class EventHandler {
  }
  int mVideoEditorHelper;
  int mVideoEditor;
  int PROJECT_CLASS_NAME;
  int INPUT_FILE_PATH;
  int PROJECT_LOCATION;
  int TAG;
}
class VideoEditorExportTest {
  int mVideoEditorHelper;
  int mVideoEditor;
  int INPUT_FILE_PATH;
  int PROJECT_LOCATION;
  int TAG;
}
class VideoEditorAPITest {
  int mVideoEditorHelper;
  int mVideoEditor;
  int PROJECT_CLASS_NAME;
  int INPUT_FILE_PATH;
  int PROJECT_LOCATION;
  int TAG;
}
class MediaPropertiesTest {
  int mVideoEditorHelper;
  int mVideoEditor;
  int INPUT_FILE_PATH;
  int PROJECT_LOCATION;
  int TAG;
}
class MediaItemThumbnailTest {
  int mVideoEditorHelper;
  int mVideoEditor;
  int INPUT_FILE_PATH;
  int PROJECT_LOCATION;
  int TAG;
}
