package com.android.defcontainer;
class MeasurementUtils {
}
class DefaultContainerService {
  int PREFER_EXTERNAL;
  int PREFER_INTERNAL;
  class ApkContainer {
    int mTag;
    int mAuthenticatedStream;
    int mInStream;
    int MAX_AUTHENTICATED_DATA_SIZE;
  }
  int mBinder;
  int LIB_DIR_NAME;
  int localLOGV;
  int TAG;
}
