package com.android.overlaytest;
class WithoutOverlayTest {
}
class WithOverlayTest {
}
class OverlayBaseTest {
  int mWithOverlay;
  int mResources;
}
