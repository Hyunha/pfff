package android.widget.gridview.touch;
class GridTouchVerticalSpacingTest {
  int mGridView;
  int mActivity;
}
class GridTouchVerticalSpacingStackFromBottomTest {
  int mViewConfig;
  int mGridView;
  int mActivity;
}
class GridTouchStackFromBottomTest {
  int mGridView;
  int mActivity;
}
class GridTouchStackFromBottomManyTest {
  int mGridView;
  int mActivity;
}
class GridTouchSetSelectionTest {
  int mGridView;
  int mActivity;
}
