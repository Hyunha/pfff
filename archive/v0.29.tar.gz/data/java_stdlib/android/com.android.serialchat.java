package com.android.serialchat;
class SerialChat {
  int mHandler;
  int MESSAGE_LOG;
  int mPermissionRequestPending;
  int mSerialPort;
  int mSerialManager;
  int mOutputBuffer;
  int mInputBuffer;
  int mEditText;
  int mLog;
  int TAG;
}
