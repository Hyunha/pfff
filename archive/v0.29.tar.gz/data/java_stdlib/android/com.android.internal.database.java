package com.android.internal.database;
class SortCursor {
  int mObserver;
  int mLastCacheHit;
  int mCurRowNumCache;
  int mCursorCache;
  int mRowNumCache;
  int ROWCACHESIZE;
  int mSortColumns;
  int mCursors;
  int mCursor;
  int TAG;
}
