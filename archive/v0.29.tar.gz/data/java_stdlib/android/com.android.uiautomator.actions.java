package com.android.uiautomator.actions;
class ToggleNafAction {
}
class ScreenshotAction {
  class ProcRunner {
    int mOutput;
    int mProcessBuilder;
  }
  int mViewer;
}
class OpenFilesAction {
  int mWindow;
}
class ImageHelper {
}
class ExpandAllAction {
  int mWindow;
}
