package com.android.framework.noloctestapp;
class NoLocTestAppActivity {
}
