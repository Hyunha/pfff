package android.widget.scroll.arrowscroll;
class TallTextAboveButtonTest {
  int mBottomButton;
  int mTopText;
  int mScrollView;
}
class ShortButtonsTest {
  int mTempRect;
  int mScrollView;
}
class MultiPageTextWithPaddingTest {
  int mTextView;
  int mScrollView;
}
class MultiPageTextWithPadding {
}
class ButtonsWithTallTextViewInBetweenTest {
  int mTempRect;
  int mBottomButton;
  int mMiddleFiller;
  int mTopButton;
  int mScrollView;
}
