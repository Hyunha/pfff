package com.android.dumprendertree2.scriptsupport;
class Starter {
  int mEverythingFinished;
  int LOG_TAG;
}
class ScriptTestRunner {
  int mTestsRelativePath;
}
class OnEverythingFinishedCallback {
}
