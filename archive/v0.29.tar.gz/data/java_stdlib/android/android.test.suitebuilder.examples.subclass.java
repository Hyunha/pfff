package android.test.suitebuilder.examples.subclass;
class SuperclassTest {
}
class SubclassTest {
}
