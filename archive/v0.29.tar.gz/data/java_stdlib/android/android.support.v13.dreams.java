package android.support.v13.dreams;
class BasicDream {
  int mPowerIntentReceiver;
  class BasicDreamView {
  }
  int mPlugged;
  int mView;
  int DEBUG;
  int TAG;
}
