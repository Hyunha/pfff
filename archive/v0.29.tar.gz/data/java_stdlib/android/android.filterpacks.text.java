package android.filterpacks.text;
class ToUpperCase {
  int mOutputFormat;
}
class StringSource {
  int mOutputFormat;
  int mString;
}
class StringLogger {
}
