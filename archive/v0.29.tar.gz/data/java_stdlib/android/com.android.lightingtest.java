package com.android.lightingtest;
class ClearRenderer {
}
class ClearGLSurfaceView {
  int mRenderer;
}
class ClearActivity {
  int mGLView;
}
