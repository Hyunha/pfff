package com.android.framework.updateexttointloctestapp;
class UpdateExtToIntLocTestAppActivity {
}
