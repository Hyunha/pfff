package com.android.test.layout;
class LinearLayoutTest {
}
class LayoutInsetsTest {
  int GRAVITIES;
}
class GridLayoutTest {
}
class AlignmentTest {
  int FACTORIES;
  int TEXT_FIELD_FACTORY;
  int LABEL_FACTORY;
  int BUTTON_FACTORY;
  class ViewFactory {
  }
  int CONTEXT;
  int VERTICAL_ALIGNMENTS;
  int VERTICAL_NAMES;
  int HORIZONTAL_ALIGNMENTS;
  int HORIZONTAL_NAMES;
}
class Activity7 {
}
class Activity6 {
}
class Activity5 {
}
class Activity4 {
}
class Activity1 {
}
class Activity0 {
}
class AbstractLayoutTest {
  int VERTICAL_ALIGNMENTS;
  int VERTICAL_NAMES;
  int HORIZONTAL_ALIGNMENTS;
  int HORIZONTAL_NAMES;
}
