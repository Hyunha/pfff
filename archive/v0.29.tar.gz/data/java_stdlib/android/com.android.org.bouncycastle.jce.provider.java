package com.android.org.bouncycastle.jce.provider;
class CertBlacklistTest {
  int DEFAULT_SERIALS;
  int DEFAULT_PUBKEYS;
  int tmpFile;
}
