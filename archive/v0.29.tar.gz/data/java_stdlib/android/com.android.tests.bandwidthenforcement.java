package com.android.tests.bandwidthenforcement;
class BandwidthEnforcementTestService {
  int OUTPUT_FILE;
  int TAG;
}
class BandwidthEnforcementTestActivity {
}
