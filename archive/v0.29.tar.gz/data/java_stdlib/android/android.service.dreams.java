package android.service.dreams;
class DreamManagerService {
  int mCurrentDreamToken;
  int mCurrentDream;
  int mCurrentDreamComponent;
  int mIWindowManager;
  int mContext;
  int mLock;
  int TAG;
  int DEBUG;
}
class Dream {
  class IDreamServiceWrapper {
  }
  int mFinished;
  int mHandler;
  int mInteractive;
  int mSandman;
  int mWindowManager;
  int mWindow;
  int SERVICE_INTERFACE;
  int TAG;
  int DEBUG;
}
