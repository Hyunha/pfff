package com.android.telephonymockriltests;
class TelephonyMockTestRunner {
  int mController;
  int TAG;
}
