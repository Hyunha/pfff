package com.example.android.rs.sto;
class SurfaceTextureOpaqueView {
  int mRender;
  int mRS;
}
class SurfaceTextureOpaqueRS {
  int mPF;
  int mRto;
  int mSto2;
  int mSto;
  int mST;
  int mScript;
  int mRS;
  int mRes;
  int NUM_CAMERA_PREVIEW_BUFFERS;
}
class SurfaceTextureOpaque {
  class cfl {
  }
  int mCFL;
  int mCC;
  int mView;
}
class CameraCapture {
  int onCameraFrameAvailableListener;
  int mListener;
  int mIsOpen;
  int mNewFrameAvailable;
  int mStartCaptureTime;
  int mHeight;
  int mWidth;
  int mCameraId;
  int mCameraTransform;
  int mPosCoordHandle;
  int mTexCoordHandle;
  int mTexSamplerHandle;
  int mCameraTransformHandle;
  int mProgram;
  int mSurfaceTexture;
  int mCamera;
  int FRAMES_PER_SEC;
  class CameraFrameListener {
  }
}
