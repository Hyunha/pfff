package com.android.commands.svc;
class WifiCommand {
}
class UsbCommand {
}
class Svc {
  int COMMANDS;
  int COMMAND_HELP;
  class Command {
    int mName;
  }
}
class PowerCommand {
}
class DataCommand {
}
