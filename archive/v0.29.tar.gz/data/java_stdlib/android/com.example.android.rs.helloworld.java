package com.example.android.rs.helloworld;
class HelloWorldView {
  int mRender;
  int mRS;
}
class HelloWorldRS {
  int mScript;
  int mRS;
  int mRes;
}
class HelloWorld {
  int mView;
}
