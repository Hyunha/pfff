package android.widget.listview.touch;
class ListTouchTest {
  int mListView;
  int mActivity;
}
class ListTouchManyTest {
  int mListView;
  int mActivity;
}
class ListTouchBottomGravityTest {
  int mListView;
  int mActivity;
}
class ListTouchBottomGravityManyTest {
  int mListView;
  int mActivity;
}
class ListSetSelectionTest {
  int mListView;
  int mActivity;
}
class ListOfTouchablesTest {
  int mListView;
  int mActivity;
}
class ListGetSelectedViewTest {
  int mListView;
  int mActivity;
}
