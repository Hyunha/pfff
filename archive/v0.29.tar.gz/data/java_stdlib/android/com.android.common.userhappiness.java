package com.android.common.userhappiness;
class UserHappinessSignals {
  int mHasVoiceLoggingInfo;
}
