package com.android.inputdevices;
class InputDeviceReceiver {
}
