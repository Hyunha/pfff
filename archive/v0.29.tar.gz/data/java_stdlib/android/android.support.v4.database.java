package android.support.v4.database;
class DatabaseUtilsCompat {
}
