package com.android.connectivitymanagertest.unit;
class WifiSoftAPTest {
  int DURATION;
  int TAG;
  int mWifiConfig;
  int mWifiManager;
}
class WifiClientTest {
  class WifiStateListener {
  }
  int mSupplicantState;
  int mSupplicantConnection;
  int mNetworkInfo;
  int mEnableBroadcastCounter;
  int mDisableBroadcastCounter;
  int mWifiState;
  int mWifiStateListener;
  int DELAY;
  int TAG;
  int mWifiManager;
}
