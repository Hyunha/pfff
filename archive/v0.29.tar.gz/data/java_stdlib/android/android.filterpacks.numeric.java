package android.filterpacks.numeric;
class SinWaveFilter {
  int mOutputFormat;
  int mValue;
  int mStepSize;
}
