package android.widget.layout.frame;
class FrameLayoutMarginTest {
  int mParent;
  int mBottomView;
  int mTopView;
  int mRightView;
  int mLeftView;
}
class FrameLayoutMargin {
}
class FrameLayoutGravityTest {
  int mParent;
  int mCenterHorizontalBottomView;
  int mRightBottomView;
  int mLeftBottomView;
  int mCenterView;
  int mRighCenterVerticalView;
  int mLeftCenterVerticalView;
  int mCenterHorizontalView;
  int mRightView;
  int mLeftView;
}
class FrameLayoutGravity {
}
