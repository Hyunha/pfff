package com.android.framework.externallocallpermstestapp;
class ExternalLocAllPermsTest {
}
