package com.android.layoutlib.bridge.android;
class BridgeXmlBlockParserTest {
}
class BridgeXmlBlockParser {
  int mPopped;
  int mEventType;
  int mStarted;
  int mPlatformFile;
  int mContext;
  int mAttrib;
  int mParser;
}
class BridgeWindowSession {
}
class BridgeWindowManager {
  int mRotation;
  int mMetrics;
  int mConfig;
}
class BridgeWindow {
}
class BridgePowerManager {
}
class BridgeLayoutParamsMapAttributes {
  int mAttributes;
}
class BridgeIInputMethodManager {
}
class BridgeContext {
  int mParserStack;
  int mContentResolver;
  int mBridgeInflater;
  int mTypedArrayCache;
  int mDynamicIdGenerator;
  int mStyleToDynamicIdMap;
  int mDynamicIdToStyleMap;
  int mDefaultPropMaps;
  int mTheme;
  int mIWindowManager;
  int mProjectCallback;
  int mApplicationInfo;
  int mConfig;
  int mRenderResources;
  int mMetrics;
  int mProjectKey;
  int mViewKeyMap;
  int mSystemResources;
}
class BridgeContentResolver {
  int mProvider;
}
class BridgeContentProvider {
}
