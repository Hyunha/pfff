package android.widget.touchmode;
class TouchModeFocusableTest {
  int mButton;
  int mEditText;
}
class TouchModeFocusChangeTest {
  int mFirstButton;
  int mActivity;
}
class StartInTouchWithViewInFocusTest {
  int mButton;
  int mEditText;
}
class FocusableInTouchModeClickTest {
}
class ChangeTouchModeTest {
}
