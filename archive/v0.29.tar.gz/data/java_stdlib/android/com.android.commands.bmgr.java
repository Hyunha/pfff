package com.android.commands.bmgr;
class Bmgr {
  class RestoreObserver {
    int sets;
    int done;
  }
  int mNextArg;
  int mArgs;
  int TRANSPORT_NOT_RUNNING_ERR;
  int BMGR_NOT_RUNNING_ERR;
  int mRestore;
  int mBmgr;
}
