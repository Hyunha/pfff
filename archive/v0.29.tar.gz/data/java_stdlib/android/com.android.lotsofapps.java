package com.android.lotsofapps;
class Nothing {
}
