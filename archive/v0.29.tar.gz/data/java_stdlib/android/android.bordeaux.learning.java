package android.bordeaux.learning;
class StochasticLinearRanker {
  int mNativeClassifier;
  class Model {
    int parameters;
    int weightNormalizer;
    int weights;
  }
  int VAR_NUM;
  int TAG;
}
class MulticlassPA {
  int nativeClassifier;
}
