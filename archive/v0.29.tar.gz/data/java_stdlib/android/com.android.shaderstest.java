package com.android.shaderstest;
class ShadersTestView {
  class ScaleListener {
  }
  int mActivePointerId;
  int INVALID_POINTER_ID;
  int mScaleDetector;
  int mRender;
  int mRS;
}
class ShadersTestRS {
  int mScript;
  int mMeshes;
  int mScreenDepth;
  int mScreen;
  int mMeshTexture;
  int mFSVignetteConst;
  int mPFVignette;
  int mPVA;
  int mPVBackground;
  int mPFBackground;
  int mPSBackground;
  int mNearestClamp;
  int mLinearClamp;
  int mRS;
  int mRes;
}
class ShadersTest {
  int mView;
}
