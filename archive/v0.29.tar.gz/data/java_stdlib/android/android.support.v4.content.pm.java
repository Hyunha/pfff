package android.support.v4.content.pm;
class ActivityInfoCompat {
  int CONFIG_UI_MODE;
}
