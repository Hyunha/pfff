package com.android.systemui.net;
class NetworkOverLimitActivity {
  int TAG;
}
