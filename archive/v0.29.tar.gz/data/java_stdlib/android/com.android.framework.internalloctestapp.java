package com.android.framework.internalloctestapp;
class InternalLocTestAppActivity {
}
