package android.widget.listview.focus;
class ListWithEditTextHeaderTest {
  int mListView;
}
class ListHorizontalFocusWithinItemWinsTest {
  int mBottomMiddleButton;
  int mTopRightButton;
  int mTopLeftButton;
  int mListView;
}
class ListButtonsDiagonalAcrossItemsTest {
  int mListView;
  int mRightButton;
  int mCenterButton;
  int mLeftButton;
}
class AdjacentListsWithAdjacentISVsInsideTest {
  int mRightIsv;
  int mRightMiddleIsv;
  int mRightListView;
  int mLeftMiddleIsv;
  int mLeftIsv;
  int mLeftListView;
}
