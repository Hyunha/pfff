package android.support.v4.accessibilityservice;
class AccessibilityServiceInfoCompatIcs {
}
class AccessibilityServiceInfoCompat {
  int FEEDBACK_ALL_MASK;
  int IMPL;
  class AccessibilityServiceInfoIcsImpl {
  }
  class AccessibilityServiceInfoStubImpl {
  }
  class AccessibilityServiceInfoVersionImpl {
  }
}
